﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Owner
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            List<BestSellingCategory> bestSellingCategories = new List<BestSellingCategory>
            {
                new BestSellingCategory { Category = "Vegetable", TurnOver = "¥26,000", IncreaseBy = "+3.2%", IncreaseByColor = Brushes.ForestGreen },
                new BestSellingCategory { Category = "Instant Food", TurnOver = "¥22,000", IncreaseBy = "-2.0%", IncreaseByColor = Brushes.Crimson },
                new BestSellingCategory { Category = "Households", TurnOver = "¥22,000", IncreaseBy = "+1.5%", IncreaseByColor = Brushes.ForestGreen }
            };
            BestSellingCategoryTable.ItemsSource = bestSellingCategories;

            List<BestSellingProduct> bestSellingProducts = new List<BestSellingProduct>
            {
                new BestSellingProduct { Product = "Tomato", ProductID = "23567", RemainingQuantity = "225 kg", ItemsSold = "500 kg", ProfitMade = "¥17,000" },
                new BestSellingProduct { Product = "Onion", ProductID = "25831", RemainingQuantity = "200 kg", ItemsSold = "450 kg", ProfitMade = "¥12,000" },
                new BestSellingProduct { Product = "Maggif", ProductID = "56841", RemainingQuantity = "200 Packet", ItemsSold = "300 Packet", ProfitMade = "¥10,000" },
                new BestSellingProduct { Product = "Surf Excel", ProductID = "23567", RemainingQuantity = "125 Packet", ItemsSold = "200 Packet", ProfitMade = "¥8,000" }
            };
            BestSellingProductTable.ItemsSource = bestSellingProducts;

            List<LowQuantityStock> lowQuantityStocks = new List<LowQuantityStock>
            {
                new LowQuantityStock { Product = "Tata Salt", Status = "LOW", RemainingQuantity = "10 Packet" },
                new LowQuantityStock { Product = "Lays", Status = "LOW", RemainingQuantity = "15 Packet" },
                new LowQuantityStock { Product = "Lays", Status = "LOW", RemainingQuantity = "15 Packet" }
            };
            LowQuantityStockTable.ItemsSource = lowQuantityStocks;

            DrawChart();
            DrawSalesPurchaseChart();
        }

        private void DrawChart()
        {
            ProfitRevenueChart.Children.Clear();

            List<double> profitData = new List<double> { 80000, 60000, 40000, 20000, 220342, 80432, 30432 };
            List<double> revenueData = new List<double> { 70000, 50000, 30000, 10000, 210342, 70432, 20432 };
            List<string> months = new List<string> { "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar" };

            double maxValue = Math.Max(profitData.Max(), revenueData.Max());
            double scaleY = 250 / maxValue;
            double scaleX = ProfitRevenueChart.ActualWidth > 0 ?
                            (ProfitRevenueChart.ActualWidth - 80) / (months.Count - 1) :
                            50;

            DrawChartBackground(ProfitRevenueChart, maxValue, scaleY, scaleX, months.Count);
            DrawLine(ProfitRevenueChart, profitData, new SolidColorBrush(Color.FromRgb(194, 24, 91)), scaleX, scaleY, "Profit");
            DrawLine(ProfitRevenueChart, revenueData, new SolidColorBrush(Color.FromRgb(25, 118, 210)), scaleX, scaleY, "Revenue");

            for (int i = 0; i < months.Count; i++)
            {
                TextBlock label = new TextBlock
                {
                    Text = months[i],
                    FontSize = 12,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(i * scaleX + 50, 260, 0, 0)
                };
                ProfitRevenueChart.Children.Add(label);
            }

            int stepSize = DetermineStepSize(maxValue);
            for (int i = 0; i <= maxValue; i += stepSize)
            {
                TextBlock label = new TextBlock
                {
                    Text = $"¥{FormatNumberWithCommas((int)i)}",
                    FontSize = 11,
                    Foreground = Brushes.DarkGray,
                    Margin = new Thickness(10, 250 - (i * scaleY), 0, 0)
                };
                ProfitRevenueChart.Children.Add(label);
            }
        }

        private void DrawSalesPurchaseChart()
        {
            SalesPurchaseChart.Children.Clear();

            List<double> salesData = new List<double> { 50000, 45000, 40000, 35000, 30000, 25000, 20000 };
            List<double> purchaseData = new List<double> { 40000, 35000, 30000, 25000, 20000, 15000, 10000 };
            List<string> months = new List<string> { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul" };

            double maxValue = Math.Max(salesData.Max(), purchaseData.Max());
            double scaleY = 250 / maxValue;
            double scaleX = SalesPurchaseChart.ActualWidth > 0 ?
                            (SalesPurchaseChart.ActualWidth - 80) / (months.Count - 1) :
                            50;

            DrawChartBackground(SalesPurchaseChart, maxValue, scaleY, scaleX, months.Count);
            DrawLine(SalesPurchaseChart, salesData, new SolidColorBrush(Color.FromRgb(255, 165, 0)), scaleX, scaleY, "Sales");
            DrawLine(SalesPurchaseChart, purchaseData, new SolidColorBrush(Color.FromRgb(50, 205, 50)), scaleX, scaleY, "Purchase");

            for (int i = 0; i < months.Count; i++)
            {
                TextBlock label = new TextBlock
                {
                    Text = months[i],
                    FontSize = 12,
                    Foreground = Brushes.Black,
                    Margin = new Thickness(i * scaleX + 50, 260, 0, 0)
                };
                SalesPurchaseChart.Children.Add(label);
            }

            int stepSize = DetermineStepSize(maxValue);
            for (int i = 0; i <= maxValue; i += stepSize)
            {
                TextBlock label = new TextBlock
                {
                    Text = $"¥{FormatNumberWithCommas((int)i)}",
                    FontSize = 11,
                    Foreground = Brushes.DarkGray,
                    Margin = new Thickness(10, 250 - (i * scaleY), 0, 0)
                };
                SalesPurchaseChart.Children.Add(label);
            }
        }

        private string FormatNumberWithCommas(int number)
        {
            return string.Format("{0:n0}", number);
        }

        private int DetermineStepSize(double maxValue)
        {
            if (maxValue > 1000000) return 200000;
            if (maxValue > 500000) return 100000;
            if (maxValue > 200000) return 50000;
            if (maxValue > 100000) return 25000;
            return 50000;
        }

        private void DrawLine(Canvas canvas, List<double> data, Brush color, double scaleX, double scaleY, string label)
        {
            Polyline polyline = new Polyline
            {
                Stroke = color,
                StrokeThickness = 3,
                StrokeLineJoin = PenLineJoin.Round
            };

            for (int i = 0; i < data.Count; i++)
            {
                polyline.Points.Add(new Point(i * scaleX + 50, 250 - (data[i] * scaleY)));
            }

            canvas.Children.Add(polyline);

            for (int i = 0; i < data.Count; i++)
            {
                Ellipse dataPoint = new Ellipse
                {
                    Width = 8,
                    Height = 8,
                    Fill = color,
                    Stroke = Brushes.White,
                    StrokeThickness = 1.5
                };

                Canvas.SetLeft(dataPoint, i * scaleX + 50 - 4);
                Canvas.SetTop(dataPoint, 250 - (data[i] * scaleY) - 4);

                ToolTip toolTip = new ToolTip
                {
                    Content = $"{label}: ¥{FormatNumberWithCommas((int)data[i])}"
                };
                dataPoint.ToolTip = toolTip;

                canvas.Children.Add(dataPoint);
            }
        }

        private void DrawChartBackground(Canvas canvas, double maxValue, double scaleY, double scaleX, int pointCount)
        {
            Rectangle background = new Rectangle
            {
                Width = (pointCount - 1) * scaleX + 100,
                Height = 280,
                Fill = new SolidColorBrush(Color.FromArgb(10, 0, 0, 0)),
                RadiusX = 5,
                RadiusY = 5
            };
            canvas.Children.Add(background);

            Line xAxis = new Line
            {
                X1 = 50,
                Y1 = 250,
                X2 = (pointCount - 1) * scaleX + 50,
                Y2 = 250,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };
            canvas.Children.Add(xAxis);

            Line yAxis = new Line
            {
                X1 = 50,
                Y1 = 0,
                X2 = 50,
                Y2 = 250,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };
            canvas.Children.Add(yAxis);

            for (int i = 0; i < pointCount; i++)
            {
                Line verticalLine = new Line
                {
                    X1 = i * scaleX + 50,
                    Y1 = 0,
                    X2 = i * scaleX + 50,
                    Y2 = 250,
                    Stroke = new SolidColorBrush(Color.FromArgb(30, 200, 200, 200)),
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection(new double[] { 4, 2 })
                };
                canvas.Children.Add(verticalLine);
            }

            int stepSize = DetermineStepSize(maxValue);
            for (int i = 0; i <= maxValue; i += stepSize)
            {
                Line horizontalLine = new Line
                {
                    X1 = 50,
                    Y1 = 250 - (i * scaleY),
                    X2 = (pointCount - 1) * scaleX + 50,
                    Y2 = 250 - (i * scaleY),
                    Stroke = new SolidColorBrush(Color.FromArgb(30, 200, 200, 200)),
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection(new double[] { 4, 2 })
                };
                canvas.Children.Add(horizontalLine);
            }
        }

        public class BestSellingCategory
        {
            public string Category { get; set; }
            public string TurnOver { get; set; }
            public string IncreaseBy { get; set; }
            public Brush IncreaseByColor { get; set; }
        }

        public class BestSellingProduct
        {
            public string Product { get; set; }
            public string ProductID { get; set; }
            public string RemainingQuantity { get; set; }
            public string ItemsSold { get; set; }
            public string ProfitMade { get; set; }
        }

        public class LowQuantityStock
        {
            public string Product { get; set; }
            public string Status { get; set; }
            public string RemainingQuantity { get; set; }
        }
    }
}