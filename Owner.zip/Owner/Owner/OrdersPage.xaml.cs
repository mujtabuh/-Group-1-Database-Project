﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Owner
{
    public partial class OrdersPage : Page
    {
        public OrdersPage()
        {
            InitializeComponent();

            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                LoadOrdersData();
            }));
        }

        private void OrdersDataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Loaded += (s, args) =>
            {
                e.Row.UpdateLayout();
            };
        }

        private void LoadOrdersData()
        {
            try
            {
                OrdersDataGrid.Visibility = Visibility.Collapsed;
                var orders = GenerateSampleOrders();
                var frozenOrders = new List<Order>(orders);
                OrdersDataGrid.ItemsSource = frozenOrders;

                Dispatcher.BeginInvoke(DispatcherPriority.Render, () =>
                {
                    OrdersDataGrid.Visibility = Visibility.Visible;
                    OrdersDataGrid.UpdateLayout();
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading orders: {ex.Message}");
            }
        }

        private List<Order> GenerateSampleOrders()
        {
            var orders = new List<Order>();

            for (int i = 1; i <= 50; i++)
            {
                var statusIndex = i % 5;
                var statusInfo = GetStatusInfo(statusIndex);

                orders.Add(new Order
                {
                    OrderID = 1000 + i,
                    Date = DateTime.Now.AddDays(-i).ToString("yyyy-MM-dd"),
                    Time = DateTime.Now.AddHours(-i).ToString("hh:mm tt"),
                    Customer = GetRandomCustomer(i),
                    CustomerInitials = GetCustomerInitials(i),
                    CustomerEmail = $"customer{i}@example.com",
                    Cashier = GetRandomCashier(i),
                    TotalAmount = $"${(i * 25.5 + 50):0.00}",
                    PaymentMethod = GetRandomPaymentMethod(i),
                    Status = statusInfo.Item1,
                    StatusBackground = statusInfo.Item2,
                    StatusForeground = Brushes.White
                });
            }

            return orders;
        }

        private Tuple<string, Brush> GetStatusInfo(int statusIndex)
        {
            switch (statusIndex)
            {
                case 0: return Tuple.Create("Completed", (Brush)new SolidColorBrush((Color)ColorConverter.ConvertFromString("#10B981")));
                case 1: return Tuple.Create("Pending", (Brush)new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F59E0B")));
                case 2: return Tuple.Create("Refunded", (Brush)new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EF4444")));
                case 3: return Tuple.Create("Partially Refunded", (Brush)new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F59E0B")));
                default: return Tuple.Create("Cancelled", (Brush)new SolidColorBrush((Color)ColorConverter.ConvertFromString("#64748B")));
            }
        }

        // Helper methods remain the same...

        private string GetRandomCustomer(int index)
        {
            string[] customers = { "John Smith", "Emily Davis", "Robert Wilson", "VIP Member",
                                 "Premium Member", "First-time Customer", "Regular Member" };
            return customers[index % customers.Length];
        }

        private string GetCustomerInitials(int index)
        {
            string[] initials = { "JS", "ED", "RW", "VM", "PM", "FC", "RM" };
            return initials[index % initials.Length];
        }

        private string GetRandomCashier(int index)
        {
            string[] cashiers = { "Sarah Johnson", "Michael Brown", "Jessica Lee", "David Wilson" };
            return cashiers[index % cashiers.Length];
        }

        private string GetRandomPaymentMethod(int index)
        {
            string[] methods = { "Credit Card", "Debit Card", "Cash", "Mobile Payment", "Cryptocurrency" };
            return methods[index % methods.Length];
        }

    }

    public class Order
    {
        public int OrderID { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string Customer { get; set; }
        public string CustomerInitials { get; set; }
        public string CustomerEmail { get; set; }
        public string Cashier { get; set; }
        public string TotalAmount { get; set; }
        public string PaymentMethod { get; set; }
        public string Status { get; set; }
        public Brush StatusBackground { get; set; }
        public Brush StatusForeground { get; set; }
    }
}

