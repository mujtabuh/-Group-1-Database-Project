﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using System.IO;
using System.ComponentModel;
using System.Windows.Media.Animation;
using System.Globalization;

namespace Owner
{
    public partial class SuppliersPage : Page, INotifyPropertyChanged
    {
        private List<Supplier> allSuppliers = new();
        private int currentPage = 1;
        private int pageSize = 10;
        private int totalPages => (int)Math.Ceiling((double)allSuppliers.Count / pageSize);

        // Properties for binding
        private string _searchText = string.Empty;
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                OnPropertyChanged(nameof(SearchText));
                FilterSuppliers();
            }
        }

        private string _selectedType = "All";
        public string SelectedType
        {
            get => _selectedType;
            set
            {
                _selectedType = value;
                OnPropertyChanged(nameof(SelectedType));
                FilterSuppliers();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public SuppliersPage()
        {
            InitializeComponent();
            this.DataContext = this;
            LoadSuppliers();
            UpdateDataGrid();
        }

        private void LoadSuppliers()
        {
            // Loading sample data - in real app this would come from a database
            allSuppliers = new List<Supplier>
            {
                new Supplier("Richard Martin", "Kit Kat", "7687764556", "richard@gmail.com", "Taking Return", "13"),
                new Supplier("Tom Homan", "Maaza", "9867545368", "tomhoman@gmail.com", "Taking Return", "-"),
                new Supplier("Veandir", "Dairy Milk", "9867545566", "veandir@gmail.com", "Not Taking Return", "-"),
                new Supplier("Charin", "Tomato", "9267545457", "charin@gmail.com", "Taking Return", "12"),
                new Supplier("Fainden Juke", "Marie Gold", "9687545982", "fainden@gmail.com", "Not Taking Return", "9"),
                // Add more suppliers for testing pagination
                new Supplier("John Doe", "Biscuits", "9876543210", "john@example.com", "Taking Return", "5"),
                new Supplier("Jane Smith", "Chocolates", "8765432109", "jane@example.com", "Not Taking Return", "-"),
                new Supplier("Robert Johnson", "Soft Drinks", "7654321098", "robert@example.com", "Taking Return", "7"),
                new Supplier("Emily Davis", "Snacks", "6543210987", "emily@example.com", "Not Taking Return", "-"),
                new Supplier("Michael Wilson", "Ice Cream", "5432109876", "michael@example.com", "Taking Return", "3"),
                new Supplier("Sarah Brown", "Chips", "4321098765", "sarah@example.com", "Not Taking Return", "-"),
                new Supplier("David Taylor", "Juices", "3210987654", "david@example.com", "Taking Return", "8")
            };
        }

        private void UpdateDataGrid()
        {
            int skip = (currentPage - 1) * pageSize;
            var pageData = allSuppliers.Skip(skip).Take(pageSize);
            SuppliersDataGrid.ItemsSource = pageData;

            // Update pagination buttons visibility
            UpdatePaginationButtons();
        }

        private void FilterSuppliers()
        {
            var filteredList = allSuppliers.AsEnumerable();

            // Filter by search text
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                filteredList = filteredList.Where(s =>
                    s.SupplierName.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                    s.Product.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                    s.Email.Contains(SearchText, StringComparison.OrdinalIgnoreCase));
            }

            // Filter by type
            if (SelectedType != "All")
            {
                filteredList = filteredList.Where(s => s.ReturnType == SelectedType);
            }

            SuppliersDataGrid.ItemsSource = filteredList.Skip((currentPage - 1) * pageSize).Take(pageSize);

            // Reset to first page when filtering
            currentPage = 1;
            UpdatePaginationButtons();
        }

        private void UpdatePaginationButtons()
        {
            // Update pagination UI logic here
            // This will be called after any filtering or page changes
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            // Clear form fields
            NameBox.Text = string.Empty;
            ProductBox.Text = string.Empty;
            CategoryBox.Text = string.Empty;
            BuyingPriceBox.Text = string.Empty;
            ContactBox.Text = string.Empty;
            EmailBox.Text = string.Empty;
            RadioTakingReturn.IsChecked = true;

            // Show modal with animation
            ModalOverlay.Visibility = Visibility.Visible;

            // Animate the modal entry
            DoubleAnimation fadeIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = TimeSpan.FromMilliseconds(300)
            };
            ModalOverlay.BeginAnimation(UIElement.OpacityProperty, fadeIn);
        }

        private void CloseModal_Click(object sender, RoutedEventArgs e)
        {
            // Animate the modal exit
            DoubleAnimation fadeOut = new DoubleAnimation
            {
                From = 1,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(200)
            };
            fadeOut.Completed += (s, _) => ModalOverlay.Visibility = Visibility.Collapsed;
            ModalOverlay.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }

        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(NameBox.Text) ||
                string.IsNullOrWhiteSpace(ProductBox.Text) ||
                string.IsNullOrWhiteSpace(ContactBox.Text))
            {
                MessageBox.Show("Please fill in all required fields", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string returnType = RadioTakingReturn.IsChecked == true ? "Taking Return" : "Not Taking Return";
            string email = EmailBox.Text;

            if (string.IsNullOrWhiteSpace(email))
            {
                email = "no-email@example.com";
            }

            // Add new supplier
            allSuppliers.Add(new Supplier(
                NameBox.Text.Trim(),
                ProductBox.Text.Trim(),
                ContactBox.Text.Trim(),
                email.Trim(),
                returnType,
                "-"
            ));

            // Close modal and update grid
            CloseModal_Click(sender, e);
            UpdateDataGrid();

            // Show confirmation message
            ShowNotification("Supplier added successfully");
        }

        private void ShowNotification(string message)
        {
            // Implementation for showing toast notification
            // This would be a small popup that appears and disappears automatically
        }

        private void DownloadAll_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                FileName = $"suppliers-{DateTime.Now:yyyy-MM-dd}.csv",
                Title = "Export Suppliers Data"
            };

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    using StreamWriter sw = new StreamWriter(dlg.FileName);
                    sw.WriteLine("Supplier Name,Product,Contact,Email,Type,On the Way");
                    foreach (var s in allSuppliers)
                    {
                        sw.WriteLine($"\"{s.SupplierName}\",\"{s.Product}\",\"{s.ContactNumber}\",\"{s.Email}\",\"{s.ReturnType}\",\"{s.OnTheWay}\"");
                    }
                    ShowNotification("Data exported successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting data: {ex.Message}", "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void PreviousPage_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--;
                UpdateDataGrid();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage < totalPages)
            {
                currentPage++;
                UpdateDataGrid();
            }
        }

        // New methods for enhanced functionality

        private void RefreshData_Click(object sender, RoutedEventArgs e)
        {
            // In a real app, this would refresh data from the database
            LoadSuppliers();
            UpdateDataGrid();
            ShowNotification("Data refreshed");
        }

        private void EditSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                // Populate form with selected supplier data
                NameBox.Text = selectedSupplier.SupplierName;
                ProductBox.Text = selectedSupplier.Product;
                ContactBox.Text = selectedSupplier.ContactNumber;
                EmailBox.Text = selectedSupplier.Email;
                RadioTakingReturn.IsChecked = selectedSupplier.ReturnType == "Taking Return";
                RadioNotTakingReturn.IsChecked = selectedSupplier.ReturnType == "Not Taking Return";

                // Show modal
                ModalOverlay.Visibility = Visibility.Visible;
            }
        }

        private void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersDataGrid.SelectedItem is Supplier selectedSupplier)
            {
                MessageBoxResult result = MessageBox.Show(
                    $"Are you sure you want to delete supplier '{selectedSupplier.SupplierName}'?",
                    "Confirm Delete",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    allSuppliers.Remove(selectedSupplier);
                    UpdateDataGrid();
                    ShowNotification("Supplier deleted");
                }
            }
        }
    }

    public class Supplier : INotifyPropertyChanged
    {
        private string _supplierName;
        public string SupplierName
        {
            get => _supplierName;
            set
            {
                _supplierName = value;
                OnPropertyChanged(nameof(SupplierName));
            }
        }

        private string _product;
        public string Product
        {
            get => _product;
            set
            {
                _product = value;
                OnPropertyChanged(nameof(Product));
            }
        }

        private string _contactNumber;
        public string ContactNumber
        {
            get => _contactNumber;
            set
            {
                _contactNumber = value;
                OnPropertyChanged(nameof(ContactNumber));
            }
        }

        private string _email;
        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }

        private string _returnType;
        public string ReturnType
        {
            get => _returnType;
            set
            {
                _returnType = value;
                OnPropertyChanged(nameof(ReturnType));
            }
        }

        private string _onTheWay;
        public string OnTheWay
        {
            get => _onTheWay;
            set
            {
                _onTheWay = value;
                OnPropertyChanged(nameof(OnTheWay));
            }
        }

        public Supplier(string supplierName, string product, string contactNumber, string email, string returnType, string onTheWay)
        {
            SupplierName = supplierName;
            Product = product;
            ContactNumber = contactNumber;
            Email = email;
            ReturnType = returnType;
            OnTheWay = onTheWay;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

   
}