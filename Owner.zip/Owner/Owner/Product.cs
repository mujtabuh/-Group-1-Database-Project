﻿using System;

namespace Owner
{
    public class Product
    {
        public string ProductName { get; set; }
        public decimal BuyingPrice { get; set; }
        public int Quantity { get; set; }
        public int Threshold { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Availability { get; set; }
    }
}