﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Owner
{
    public class AvailabilityToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string availability)
            {
                return availability switch
                {
                    "In Stock" => new SolidColorBrush(Color.FromRgb(16, 185, 129)), // Green
                    "Low Stock" => new SolidColorBrush(Color.FromRgb(245, 158, 11)), // Amber
                    "Out of Stock" => new SolidColorBrush(Color.FromRgb(239, 68, 68)), // Red
                    _ => new SolidColorBrush(Color.FromRgb(156, 163, 175)) // Gray
                };
            }
            return new SolidColorBrush(Color.FromRgb(156, 163, 175)); // Gray
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}