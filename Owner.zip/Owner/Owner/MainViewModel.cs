﻿using System;
using System.Collections.Generic;

namespace Owner
{
    public class MainViewModel
    {
        public List<Product> Products { get; set; }

        public MainViewModel()
        {
            LoadDummyData();
        }

        private void LoadDummyData()
        {
            Products = new List<Product>
            {
                new Product { ProductName = "Cashews", BuyingPrice = 100.00m, Quantity = 50, Threshold = 10, ExpiryDate = DateTime.Now.AddMonths(6), Availability = "In Stock" },
                new Product { ProductName = "Almonds", BuyingPrice = 120.00m, Quantity = 30, Threshold = 5, ExpiryDate = DateTime.Now.AddMonths(6), Availability = "In Stock" },
                new Product { ProductName = "Pistachios", BuyingPrice = 150.00m, Quantity = 20, Threshold = 3, ExpiryDate = DateTime.Now.AddMonths(4), Availability = "Low Stock" },
                new Product { ProductName = "Walnuts", BuyingPrice = 90.00m, Quantity = 10, Threshold = 2, ExpiryDate = DateTime.Now.AddMonths(2), Availability = "Low Stock" },
                new Product { ProductName = "Hazelnuts", BuyingPrice = 130.00m, Quantity = 25, Threshold = 5, ExpiryDate = DateTime.Now.AddMonths(5), Availability = "In Stock" },
            };
        }
    }
}