﻿using System.Windows.Controls;

namespace Owner
{
    public partial class InventoryPage : Page
    {
        public InventoryPage()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
    }
}