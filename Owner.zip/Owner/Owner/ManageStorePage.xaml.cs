﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace Owner
{
    public partial class ManageStorePage : INotifyPropertyChanged
    {
        private ObservableCollection<StoreModel> _stores;

        public ObservableCollection<StoreModel> Stores
        {
            get => _stores;
            set
            {
                _stores = value;
                OnPropertyChanged();
            }
        }

        public ICommand AddStoreCommand { get; private set; }
        public ICommand EditStoreCommand { get; private set; }

        public ManageStorePage()
        {
            InitializeComponent();
            DataContext = this;

            // Initialize commands
            AddStoreCommand = new RelayCommand(ExecuteAddStore);
            EditStoreCommand = new RelayCommand<StoreModel>(ExecuteEditStore);

            // Load sample data
            LoadStores();
        }

        private void LoadStores()
        {
            Stores = new ObservableCollection<StoreModel>
            {
                new StoreModel
                {
                    BranchName = "Islamabad Branch",
                    StoreName = "Insaaf Dry Fruits",
                    Address = "F-7 Markaz, Jinnah Super Market",
                    CityPincode = "Islamabad - 44000",
                    Phone = "051-2654789"
                },
                new StoreModel
                {
                    BranchName = "Lahore Branch",
                    StoreName = "Insaaf Dry Fruits",
                    Address = "MM Alam Road, Gulberg III",
                    CityPincode = "Lahore - 54660",
                    Phone = "042-35778912"
                },
                new StoreModel
                {
                    BranchName = "Karachi Branch",
                    StoreName = "Insaaf Dry Fruits",
                    Address = "26th Street, Phase V, DHA",
                    CityPincode = "Karachi - 75500",
                    Phone = "021-35345678"
                }
            };
        }

        private void ExecuteAddStore(object parameter)
        {
            // Implementation for adding a new branch
            MessageBox.Show("Add Branch functionality will be implemented here.");
        }

        private void ExecuteEditStore(StoreModel store)
        {
            if (store != null)
            {
                // Implementation for editing a branch
                MessageBox.Show($"Edit Branch functionality for {store.BranchName} will be implemented here.");
            }
        }

        // INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // Store Model
    public class StoreModel
    {
        public string BranchName { get; set; }
        public string StoreName { get; set; }
        public string Address { get; set; }
        public string CityPincode { get; set; }
        public string Phone { get; set; }
    }

    // Simple Relay Command Implementation
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }

    // Generic Relay Command
    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Predicate<T> _canExecute;

        public RelayCommand(Action<T> execute, Predicate<T> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute((T)parameter);
        }

        public void Execute(object parameter)
        {
            _execute((T)parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}