﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Cashier.Controls
{
    public partial class TopNavBar : UserControl
    {
        public TopNavBar()
        {
            InitializeComponent();
            SearchBox.GotFocus += SearchBox_GotFocus;
            SearchBox.LostFocus += SearchBox_LostFocus;
            SearchBox.KeyUp += SearchBox_KeyUp;
            ToggleSidebarBtn.Click += ToggleSidebar_Click;
            NotificationBtn.Click += Notification_Click;
            ProfileBtn.Click += Profile_Click;
        }

        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.ToggleSidebar();
            }
        }

        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SearchBox.Text == "🔍 Search product, supplier, order")
            {
                SearchBox.Text = "";
                SearchBox.Foreground = Brushes.Black;
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                SearchBox.Text = "🔍 Search product, supplier, order";
                SearchBox.Foreground = Brushes.Gray;
            }
        }

        private void SearchBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                string searchTerm = SearchBox.Text.Trim();
                var mainWindow = Window.GetWindow(this) as MainWindow;
                if (mainWindow != null)
                {
                    mainWindow.HandleSearch(searchTerm);
                }
            }
        }

        private void Notification_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.ShowNotification();
            }
        }

        private void Profile_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.ShowProfile();
            }
        }
    }
}