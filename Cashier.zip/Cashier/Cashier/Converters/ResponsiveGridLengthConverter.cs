﻿using System.Globalization;
using System.Windows.Data;
using System.Windows;
using System;

public class ResponsiveGridLengthConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (SystemParameters.PrimaryScreenWidth < 768) // Mobile
            return new GridLength(1, GridUnitType.Star); // Single column
        return new GridLength(150); // Fixed width for desktop
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}