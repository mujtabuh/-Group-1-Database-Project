﻿using Cashier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace InsafDryFruits
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainWindow());
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Profile clicked.");
        }

        private void ProductLookup_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Product Lookup clicked.");
        }

        private void Discounts_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Profile clicked.");
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logging out...");
            Application.Current.Shutdown();
        }

        private void ToggleSidebar(object sender, RoutedEventArgs e)
        {
            SidebarColumn.Width = SidebarColumn.Width.Value == 0 ? new GridLength(220) : new GridLength(0);
        }

        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SearchBox.Text == "🔍 Search product, supplier, order")
            {
                SearchBox.Text = "";
                SearchBox.Foreground = System.Windows.Media.Brushes.Black;
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                SearchBox.Text = "🔍 Search product, supplier, order";
                SearchBox.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void Notification_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Notifications clicked.");
        }

        private void Profile_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Profile clicked.");
        }
    }
}

