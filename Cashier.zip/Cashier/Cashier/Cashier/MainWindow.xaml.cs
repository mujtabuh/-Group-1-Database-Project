﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Collections.ObjectModel;
using System.Windows.Controls.Primitives;
using InsafDryFruits;


namespace Cashier
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadCartData();
            SetActiveButton(DashboardButton);
        }

        // Toggle Sidebar Visibility
        private void ToggleSidebar(object sender, RoutedEventArgs e)
        {
            if (SidebarColumn.Width.Value > 0)
                SidebarColumn.Width = new GridLength(0);  // Hide sidebar
            else
                SidebarColumn.Width = new GridLength(220);  // Show sidebar
        }

        // Handle Search Box Placeholder Text
        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SearchBox.Text == "🔍 Search product, supplier, order")
            {
                SearchBox.Text = "";
                SearchBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                SearchBox.Text = "🔍 Search product, supplier, order";
                SearchBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
        }

        // Simulating Cart Data Load
        private void LoadCartData()
        {
            List<CartItem> cartItems = new List<CartItem>
            {
                new CartItem { Name = "Almonds", Price = 500, Quantity = 2, TransactionDate = DateTime.Now, ProductID = "P1001", TotalPrice = 1000 },
                new CartItem { Name = "Cashews", Price = 700, Quantity = 1, TransactionDate = DateTime.Now, ProductID = "P1002", TotalPrice = 700 }
            };

            CartTable.ItemsSource = cartItems;
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            SetActiveButton(ReportsButton);
            MainFrame.Navigate(new ReportsPage());
        }



        private void ProductLookup_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Opening Product Lookup...");
        }

        private void Discounts_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Applying Discounts...");
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logging out...");
            Application.Current.Shutdown();
        }

        // Notification & Profile
        private void Notification_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You have no new notifications.");
        }

        private void Profile_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Opening Profile...");
        }

        // Payment Options Popup
        private void PaymentOptions_Click(object sender, RoutedEventArgs e)
        {
            PaymentPopup.IsOpen = true;
        }

        private void CreditCard_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Processing Credit Card Payment...");
            PaymentPopup.IsOpen = false;
        }

        private void Easypaisa_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Processing Easypaisa Payment...");
            PaymentPopup.IsOpen = false;
        }

        private void JazzCash_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Processing JazzCash Payment...");
            PaymentPopup.IsOpen = false;
        }

        private void SetActiveButton(Button activeButton)
        {
            // Reset all buttons to default style
            DashboardButton.Style = (Style)FindResource("SidebarButtonStyle");
            ReportsButton.Style = (Style)FindResource("SidebarButtonStyle");
            ProductLookupButton.Style = (Style)FindResource("SidebarButtonStyle");
            DiscountsButton.Style = (Style)FindResource("SidebarButtonStyle");

            // Apply active style to the clicked button
            activeButton.Style = (Style)FindResource("ActiveSidebarButtonStyle");
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            SetActiveButton(DashboardButton);
            MessageBox.Show("Navigating to Dashboard...");
        }
    }

    

    // Cart Item Model
    public class CartItem
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public int Quantity { get; set; }
        public DateTime TransactionDate { get; set; }
        public string ProductID { get; set; }
        public int TotalPrice { get; set; }
    }
}




