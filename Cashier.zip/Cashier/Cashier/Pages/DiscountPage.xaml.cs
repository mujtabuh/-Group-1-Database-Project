﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using static Cashier.MainWindow;

namespace Cashier
{
    public partial class DiscountPage : Page
    {
        public class Order
        {
            public string OrderId { get; set; }
            public DateTime Date { get; set; }
            public decimal Total { get; set; }
            public List<CartItem> Items { get; set; }
        }

        private List<Order> _sampleOrders = new List<Order>();

        public DiscountPage()
        {
            InitializeComponent();
            InitializeSampleData();
            FromDatePicker.SelectedDate = DateTime.Today.AddDays(-7);
            ToDatePicker.SelectedDate = DateTime.Today;
        }

        private void InitializeSampleData()
        {
            _sampleOrders = new List<Order>
            {
                new Order {
                    OrderId = "INV-20231115-001",
                    Date = DateTime.Today.AddDays(-1),
                    Total = 1700,
                    Items = new List<CartItem> {
                        new CartItem("Almonds", 500, 2, "P1001"),
                        new CartItem("Cashews", 700, 1, "P1002")
                    }
                },
                new Order {
                    OrderId = "INV-20231114-001",
                    Date = DateTime.Today.AddDays(-2),
                    Total = 2400,
                    Items = new List<CartItem> {
                        new CartItem("Pistachios", 800, 3, "P1003")
                    }
                }
            };

            OrdersGrid.ItemsSource = _sampleOrders;
        }

        private void SearchByDate_Click(object sender, RoutedEventArgs e)
        {
            if (FromDatePicker.SelectedDate == null || ToDatePicker.SelectedDate == null) return;

            var fromDate = FromDatePicker.SelectedDate.Value;
            var toDate = ToDatePicker.SelectedDate.Value;

            var filteredOrders = _sampleOrders.FindAll(o => o.Date >= fromDate && o.Date <= toDate);
            OrdersGrid.ItemsSource = filteredOrders;
        }

        private void OrdersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrdersGrid.SelectedItem is Order selectedOrder)
            {
                OrderHeaderText.Text = $"Order: {selectedOrder.OrderId} | {selectedOrder.Date:yyyy-MM-dd} | Total: IDR {selectedOrder.Total}";
                OrderItemsGrid.ItemsSource = selectedOrder.Items;
                CalculateRefundAmount();
            }
        }

        private void RestockingFeeCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            CalculateRefundAmount();
        }

        private void CalculateRefundAmount()
        {
            if (!(OrdersGrid.SelectedItem is Order selectedOrder)) return;

            decimal subtotal = 0;
            foreach (CartItem item in OrderItemsGrid.Items)
            {
                subtotal += item.TotalPrice;
            }

            if (RestockingFeeCheckBox.IsChecked == true)
            {
                subtotal *= 0.9m;
            }

            RefundAmountText.Text = $"IDR {subtotal}";
        }

        private void ProcessRefund_Click(object sender, RoutedEventArgs e)
        {
            if (!(OrdersGrid.SelectedItem is Order selectedOrder))
            {
                MessageBox.Show("Please select an order first", "No Order Selected",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            decimal refundAmount = decimal.Parse(RefundAmountText.Text.Replace("IDR ", ""));
            MessageBox.Show($"Refund processed for {selectedOrder.OrderId}\nAmount: IDR {refundAmount}",
                          "Refund Complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}