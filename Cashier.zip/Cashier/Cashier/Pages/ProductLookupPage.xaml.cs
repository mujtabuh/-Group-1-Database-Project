﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Cashier.Models;

namespace Cashier.Pages
{
    public partial class ProductLookupPage : Page, INotifyPropertyChanged
    {
        private ObservableCollection<Product> _products;
        private Dictionary<string, Product> _productLookupByName;
        private Dictionary<string, Product> _productLookupById;
        private bool _isProductFound;
        private Product _currentProduct;

        public event PropertyChangedEventHandler PropertyChanged;

        public bool IsProductFound
        {
            get => _isProductFound;
            set
            {
                _isProductFound = value;
                OnPropertyChanged(nameof(IsProductFound));
            }
        }

        // Product Details Properties
        public new string Name => _currentProduct?.Name;
        public string ProductID => _currentProduct?.ProductID;
        public string Category => _currentProduct?.Category;
        public decimal Price => _currentProduct?.Price ?? 0;
        public int Quantity => _currentProduct?.Quantity ?? 0;
        public string ExpiryDate => _currentProduct?.ExpiryDate;
        public string ThresholdValue => _currentProduct?.ThresholdValue;

        // Supplier Details
        public string SupplierName => _currentProduct?.SupplierName;
        public string SupplierContact => _currentProduct?.SupplierContact;

        // Stock Information
        public string OpeningStock => _currentProduct?.OpeningStock;
        public string RemainingStock => _currentProduct?.RemainingStock;
        public string OnTheWay => _currentProduct?.OnTheWay;

        // Stock Locations
        public List<StockLocation> StockLocations => _currentProduct?.StockLocations;

        public ProductLookupPage()
        {
            InitializeComponent();
            InitializeProductData();
            DataContext = this;
            IsProductFound = false;
        }

        public void PerformSearch(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                ResetSearch();
                return;
            }

            Product foundProduct = null;
            if (_productLookupByName.TryGetValue(searchTerm, out foundProduct) ||
                _productLookupById.TryGetValue(searchTerm, out foundProduct))
            {
                _currentProduct = foundProduct;
                NotifyAllProductProperties();
                IsProductFound = true;
            }
            else
            {
                _currentProduct = null;
                NotifyAllProductProperties();
                IsProductFound = false;
                MessageBox.Show("Product not found", "Search", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void InitializeProductData()
        {
            // This will be replaced with database calls
            var products = new List<Product>
            {
                new Product {
                    Name = "Almonds",
                    ProductID = "P1001",
                    Category = "Dry Fruits",
                    Price = 500,
                    Quantity = 50,
                    ExpiryDate = "21/12/2025",
                    ThresholdValue = "12",
                    SupplierName = "Ronald Martin",
                    SupplierContact = "98789 86757",
                    OpeningStock = "40",
                    RemainingStock = "34",
                    OnTheWay = "15",
                    ProductImagePath = "/Images/almonds.png",
                    StockLocations = new List<StockLocation> {
                        new StockLocation { StoreName = "Sulur Branch", StockInHand = "15" },
                        new StockLocation { StoreName = "Singanallur Branch", StockInHand = "19" }
                    }
                },
                new Product {
                    Name = "Cashews",
                    ProductID = "P1002",
                    Category = "Dry Fruits",
                    Price = 700,
                    Quantity = 30,
                    ExpiryDate = "15/10/2025",
                    ThresholdValue = "10",
                    SupplierName = "Elijah Foods",
                    SupplierContact = "94567 12398",
                    OpeningStock = "35",
                    RemainingStock = "18",
                    OnTheWay = "10",
                    ProductImagePath = "/Images/cashews.png",
                    StockLocations = new List<StockLocation> {
                        new StockLocation { StoreName = "Sulur Branch", StockInHand = "10" },
                        new StockLocation { StoreName = "Singanallur Branch", StockInHand = "8" }
                    }
                },
                new Product {
                    Name = "Walnuts",
                    ProductID = "P1003",
                    Category = "Dry Fruits",
                    Price = 600,
                    Quantity = 20,
                    ExpiryDate = "30/11/2025",
                    ThresholdValue = "8",
                    SupplierName = "Global Nuts Co.",
                    SupplierContact = "99876 54321",
                    OpeningStock = "25",
                    RemainingStock = "17",
                    OnTheWay = "12",
                    ProductImagePath = "/Images/walnuts.png",
                    StockLocations = new List<StockLocation> {
                        new StockLocation { StoreName = "Sulur Branch", StockInHand = "12" },
                        new StockLocation { StoreName = "Singanallur Branch", StockInHand = "5" }
                    }
                }
            };

            _products = new ObservableCollection<Product>(products);
            _productLookupByName = products.ToDictionary(p => p.Name, StringComparer.OrdinalIgnoreCase);
            _productLookupById = products.ToDictionary(p => p.ProductID, StringComparer.OrdinalIgnoreCase);
        }

        private void ResetSearch()
        {
            _currentProduct = null;
            NotifyAllProductProperties();
            IsProductFound = false;
        }

        private void NotifyAllProductProperties()
        {
            var properties = new[]
            {
                nameof(Name), nameof(ProductID), nameof(Category), nameof(Price),
                nameof(Quantity), nameof(ExpiryDate), nameof(ThresholdValue),
                nameof(SupplierName), nameof(SupplierContact), nameof(OpeningStock),
                nameof(RemainingStock), nameof(OnTheWay), nameof(StockLocations)
            };

            foreach (var property in properties)
            {
                OnPropertyChanged(property);
            }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}