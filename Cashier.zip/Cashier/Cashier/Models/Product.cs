﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using static Cashier.Pages.ProductLookupPage;

namespace Cashier.Models
{
    public class Product : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _name;
        private string _productID;
        private string _category;
        private decimal _price;
        private int _quantity;
        private string _expiryDate;
        private string _thresholdValue;
        private string _supplierName;
        private string _supplierContact;
        private string _openingStock;
        private string _remainingStock;
        private string _onTheWay;
        private string _productImagePath;
        private List<StockLocation> _stockLocations = new List<StockLocation>();

        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        public string ProductID
        {
            get => _productID;
            set { _productID = value; OnPropertyChanged(nameof(ProductID)); }
        }

        public string Category
        {
            get => _category;
            set { _category = value; OnPropertyChanged(nameof(Category)); }
        }

        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged(nameof(Price)); }
        }

        public int Quantity
        {
            get => _quantity;
            set { _quantity = value; OnPropertyChanged(nameof(Quantity)); }
        }

        public string ExpiryDate
        {
            get => _expiryDate;
            set { _expiryDate = value; OnPropertyChanged(nameof(ExpiryDate)); }
        }

        public string ThresholdValue
        {
            get => _thresholdValue;
            set { _thresholdValue = value; OnPropertyChanged(nameof(ThresholdValue)); }
        }

        public string SupplierName
        {
            get => _supplierName;
            set { _supplierName = value; OnPropertyChanged(nameof(SupplierName)); }
        }

        public string SupplierContact
        {
            get => _supplierContact;
            set { _supplierContact = value; OnPropertyChanged(nameof(SupplierContact)); }
        }

        public string OpeningStock
        {
            get => _openingStock;
            set { _openingStock = value; OnPropertyChanged(nameof(OpeningStock)); }
        }

        public string RemainingStock
        {
            get => _remainingStock;
            set { _remainingStock = value; OnPropertyChanged(nameof(RemainingStock)); }
        }

        public string OnTheWay
        {
            get => _onTheWay;
            set { _onTheWay = value; OnPropertyChanged(nameof(OnTheWay)); }
        }

        public string ProductImagePath
        {
            get => _productImagePath;
            set
            {
                _productImagePath = value;
                OnPropertyChanged(nameof(ProductImagePath));
                OnPropertyChanged(nameof(ProductImageSource));
            }
        }

        public List<StockLocation> StockLocations
        {
            get => _stockLocations;
            set { _stockLocations = value; OnPropertyChanged(nameof(StockLocations)); }
        }

        public BitmapImage ProductImageSource
        {
            get
            {
                if (string.IsNullOrEmpty(ProductImagePath))
                    return null;

                try
                {
                    BitmapImage image = new BitmapImage();
                    image.BeginInit();
                    image.UriSource = new Uri(ProductImagePath.StartsWith("/") ?
                        $"pack://application:,,,{ProductImagePath}" : ProductImagePath);
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.EndInit();
                    return image;
                }
                catch
                {
                    return null;
                }
            }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}