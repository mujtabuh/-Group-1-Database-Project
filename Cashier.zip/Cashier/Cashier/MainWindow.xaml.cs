﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Cashier
{
    public partial class MainWindow : Window
    {
        private string _currentOrderId;
        private double _currentSubtotal;
        private double _currentDiscount;

        public MainWindow()
        {
            InitializeComponent();
            InitializeApplication();
        }

        private void InitializeApplication()
        {
            InitializeDashboard();
            SetActiveNavigationButton(DashboardButton);
            LoadSampleCartData();
        }

        private void InitializeDashboard()
        {
            // Initialization code for dashboard
        }

        private void SetActiveNavigationButton(Button activeButton)
        {
            DashboardButton.Style = (Style)FindResource("SidebarButtonStyle");
            ReportsButton.Style = (Style)FindResource("SidebarButtonStyle");
            ProductLookupButton.Style = (Style)FindResource("SidebarButtonStyle");
            DiscountsButton.Style = (Style)FindResource("SidebarButtonStyle");

            activeButton.Style = (Style)FindResource("ActiveSidebarButtonStyle");
        }

        private void ShowView(UIElement viewToShow, UIElement viewToHide)
        {
            viewToShow.Visibility = Visibility.Visible;
            viewToHide.Visibility = Visibility.Collapsed;
        }

        private void NavigateToPage(Uri pageUri)
        {
            ShowView(MainFrame, DashboardView);
            MainFrame.Navigate(pageUri);
        }

        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            SetActiveNavigationButton(DashboardButton);
            ShowView(DashboardView, MainFrame);
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            SetActiveNavigationButton(ReportsButton);
            NavigateToPage(new Uri("Pages/ReportsPage.xaml", UriKind.Relative));
        }

        private void ProductLookup_Click(object sender, RoutedEventArgs e)
        {
            SetActiveNavigationButton(ProductLookupButton);
            NavigateToPage(new Uri("Pages/ProductLookupPage.xaml", UriKind.Relative));
        }

        private void Discounts_Click(object sender, RoutedEventArgs e)
        {
            SetActiveNavigationButton(DiscountsButton);
            NavigateToPage(new Uri("Pages/DiscountPage.xaml", UriKind.Relative));
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to logout?",
                                       "Logout Confirmation",
                                       MessageBoxButton.YesNo,
                                       MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void LoadSampleCartData()
        {
            var cartItems = new List<CartItem>
            {
                new CartItem("Almonds", 500, 2, "P1001"),
                new CartItem("Cashews", 700, 1, "P1002")
            };

            CartTable.ItemsSource = cartItems;
        }

        private void PaymentOptions_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Payment options dialog would appear here",
                          "Payment Options",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void GenerateInvoice_Click(object sender, RoutedEventArgs e)
        {
            // Generate a new order ID
            _currentOrderId = $"INV-{DateTime.Now:yyyyMMdd-HHmmss}";
            OrderIdText.Text = _currentOrderId;

            // Set the invoice table data
            InvoiceTable.ItemsSource = CartTable.ItemsSource;

            // Calculate subtotal
            _currentSubtotal = 0;
            foreach (CartItem item in CartTable.Items)
            {
                _currentSubtotal += item.TotalPrice;
            }

            _currentDiscount = 0;
            SubtotalText.Text = $"IDR {_currentSubtotal}";
            TotalText.Text = $"IDR {_currentSubtotal}";

            // Show the popup
            InvoicePopup.IsOpen = true;
        }

        private void DiscountTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (DiscountTextBox.Text == "Discount Code")
            {
                DiscountTextBox.Text = "";
                DiscountTextBox.Foreground = Brushes.Black;
            }
        }

        private void DiscountTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(DiscountTextBox.Text))
            {
                DiscountTextBox.Text = "Discount Code";
                DiscountTextBox.Foreground = Brushes.Gray;
            }
        }

        private void ApplyDiscount_Click(object sender, RoutedEventArgs e)
        {
            if (DiscountTextBox.Text == "Discount Code" || string.IsNullOrWhiteSpace(DiscountTextBox.Text))
            {
                MessageBox.Show("Please enter a discount code", "Invalid Discount",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Here you would typically validate the discount code
            // For now, we'll just apply a 10% discount as an example
            _currentDiscount = _currentSubtotal * 0.1; // 10% discount
            double total = _currentSubtotal - _currentDiscount;

            TotalText.Text = $"IDR {total}";
            MessageBox.Show($"Discount applied! You saved IDR {_currentDiscount}",
                           "Discount Applied", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CancelInvoice_Click(object sender, RoutedEventArgs e)
        {
            InvoicePopup.IsOpen = false;
            ResetInvoiceFields();
        }

        private void GenerateInvoiceConfirm_Click(object sender, RoutedEventArgs e)
        {
            // Here you would typically save the invoice to database
            var invoiceDetails = new
            {
                OrderId = _currentOrderId,
                Items = CartTable.ItemsSource,
                Subtotal = _currentSubtotal,
                Discount = _currentDiscount,
                Total = _currentSubtotal - _currentDiscount,
                DateTime = DateTime.Now
            };

            // Show confirmation
            MessageBox.Show($"Invoice {_currentOrderId} generated successfully!\nTotal: IDR {_currentSubtotal - _currentDiscount}",
                           "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            InvoicePopup.IsOpen = false;
            ResetInvoiceFields();

            // Here you would typically clear the cart or create a new order
            // CartTable.ItemsSource = null;
        }

        private void ResetInvoiceFields()
        {
            DiscountTextBox.Text = "Discount Code";
            DiscountTextBox.Foreground = Brushes.Gray;
            _currentOrderId = string.Empty;
            _currentSubtotal = 0;
            _currentDiscount = 0;
        }

        public void ToggleSidebar()
        {
            SidebarColumn.Width = SidebarColumn.Width.Value > 0 ?
                new GridLength(0) :
                new GridLength(220);
        }

        public void HandleSearch(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm)) return;

            if (MainFrame.Content is Pages.ProductLookupPage productLookupPage)
            {
                productLookupPage.PerformSearch(searchTerm);
            }
            else
            {
                ProductLookup_Click(null, null);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (MainFrame.Content is Pages.ProductLookupPage newPage)
                    {
                        newPage.PerformSearch(searchTerm);
                    }
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        public void ShowNotification()
        {
            MessageBox.Show("You have no new notifications.",
                           "Notifications",
                           MessageBoxButton.OK,
                           MessageBoxImage.Information);
        }

        public void ShowProfile()
        {
            UpdateProfileInfo();
            ProfilePopup.IsOpen = true;
        }

        private void UpdateProfileInfo()
        {
            var profileImageBrush = (ImageBrush)FindResource("ProfileImageBrush");
            profileImageBrush.ImageSource = new BitmapImage(
                new Uri("Icons/profile.jpg", UriKind.RelativeOrAbsolute));

            ProfileNameTextBlock.Text = "Samantha Jones";
            ProfileStatsTextBlock.Text = "Data Processor - Tech Specialist";
        }

        private void ChangeProfilePhoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*",
                Title = "Select a Profile Photo"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                var profileImageBrush = (ImageBrush)FindResource("ProfileImageBrush");
                profileImageBrush.ImageSource = new BitmapImage(new Uri(openFileDialog.FileName));
            }
        }

        public class CartItem
        {
            public string Name { get; }
            public int Price { get; }
            public int Quantity { get; }
            public DateTime TransactionDate { get; }
            public string ProductID { get; }
            public int TotalPrice => Price * Quantity;

            public CartItem(string name, int price, int quantity, string productId)
            {
                Name = name;
                Price = price;
                Quantity = quantity;
                ProductID = productId;
                TransactionDate = DateTime.Now;
            }
        }

        public class Invoice
        {
            public string OrderId { get; set; }
            public List<CartItem> Items { get; set; }
            public double Subtotal { get; set; }
            public double Discount { get; set; }
            public double Total => Subtotal - Discount;
            public DateTime InvoiceDate { get; set; }
        }
    }
}